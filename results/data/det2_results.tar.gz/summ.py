import json, glob, sys
for fn in sorted(glob.glob('det2/p0.*/results.json')):
    r=json.load(open(fn)); print('==',fn.split('/')[1],'A',r['pfail_A'],'B',r['pfail_B'])
    for k,v in r['trackers'].items():
        d=v['det']; print(f"{k:9s} f={v['f']:.3f} [{v['f_ci'][0]:.2f},{v['f_ci'][1]:.2f}] AP={d['AP']:.3f} prec={d['precision']:.2f} rec={d['recall']:.2f}")
    for k,v in r['mcnemar'].items():
        if any(s in k for s in ['ALL_vs_old','ALL_h_vs','glob','lag2']): print(' ',k, v['x_right_only'], v['y_right_only'], f"{v['p']:.3g}")
